package com.bugra.calculator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;
import java.math.BigDecimal;


public class CalculatorController {
    private double lastResult = 0;
    private boolean startNewOperation = true;
    @FXML
    private TextField resultTextField;

    @FXML
    private TextField buttonTextDisplayField;

    private StringBuilder operation = new StringBuilder();

    @FXML
    private void handleCeButtonAction() {
        resultTextField.clear();
        buttonTextDisplayField.clear();
    }

    @FXML
    private void handleCButtonAction() {
        operation.setLength(0);
        resultTextField.clear();
        buttonTextDisplayField.clear();
    }

    @FXML
    private void handleBackspaceButtonAction() {
        if (operation.length() > 0) {
            operation.deleteCharAt(operation.length() - 1);
            buttonTextDisplayField.setText(operation.toString());
        }
    }

    @FXML
    private void handleReciprocalButtonAction() {
        try {
            double value = Double.parseDouble(resultTextField.getText());
            if (value != 0) {
                resultTextField.setText(String.valueOf(1 / value));
                operation.setLength(0);
                operation.append(resultTextField.getText());
                buttonTextDisplayField.setText(operation.toString());
            } else {
                resultTextField.setText("Error");
            }
        } catch (NumberFormatException e) {
            resultTextField.setText("Error");
        }
    }

    @FXML
    private void handleSquareButtonAction() {
        try {
            double value = Double.parseDouble(resultTextField.getText());
            resultTextField.setText(String.valueOf(value * value));
            operation.setLength(0);
            operation.append(resultTextField.getText());
            buttonTextDisplayField.setText(operation.toString());
        } catch (NumberFormatException e) {
            resultTextField.setText("Error");
        }
    }

    @FXML
    private void handleRootButtonAction() {
        try {
            double value = Double.parseDouble(resultTextField.getText());
            if (value >= 0) {
                resultTextField.setText(String.valueOf(Math.sqrt(value)));
                operation.setLength(0);
                operation.append(resultTextField.getText());
                buttonTextDisplayField.setText(operation.toString());
            } else {
                resultTextField.setText("Error");
            }
        } catch (NumberFormatException e) {
            resultTextField.setText("Error");
        }
    }

    @FXML
    private void handleOperatorButtonAction(ActionEvent event) {
        if (startNewOperation) {
            operation.setLength(0);
            operation.append(lastResult);
            startNewOperation = false;
        }
        Button clickedButton = (Button) event.getSource();
        String buttonText = clickedButton.getText();
        String operator = handleOperatorButton(buttonText);
        if (!operator.isEmpty()) {
            appendToOperation(operator);
        }
    }

    @FXML
    private void handleNumberButtonAction(ActionEvent event) {
        Button clickedButton = (Button) event.getSource();
        String buttonText = clickedButton.getText();

        // Eğer yeni bir işlem başlatılmışsa veya son girilen karakter bir operatörse, sonucu temizle
        if (startNewOperation || (!operation.isEmpty() && !Character.isDigit(operation.charAt(operation.length() - 1)) && operation.charAt(operation.length() - 1) != '.')) {
            resultTextField.clear();
            startNewOperation = false;
        }

        resultTextField.setText(resultTextField.getText() + buttonText);
        appendToOperation(buttonText);
    }



    private void appendToOperation(String text) {
        operation.append(text);
        buttonTextDisplayField.setText(operation.toString());
    }

    @FXML
    private void handleToggleSign() {
        try {
            double value = Double.parseDouble(resultTextField.getText());
            resultTextField.setText(String.valueOf(-value));
            operation.setLength(0);
            operation.append(resultTextField.getText());
            buttonTextDisplayField.setText(operation.toString());
        } catch (NumberFormatException e) {
            resultTextField.setText("Error");
        }
    }

    @FXML
    private void handelCalculatePercentage() {
        try {
            double value = Double.parseDouble(resultTextField.getText());
            resultTextField.setText(String.valueOf(value / 100));
            operation.setLength(0);
            operation.append(resultTextField.getText());
            buttonTextDisplayField.setText(operation.toString());
        } catch (NumberFormatException e) {
            resultTextField.setText("Error");
        }
    }

    @FXML
    private void handleDecimalButtonAction() {
        String currentText = resultTextField.getText();
        if (!currentText.contains(".")) {
            resultTextField.setText(currentText + ".");
        } else {
            // Eğer zaten bir ondalık nokta varsa, yeni bir tane eklemeye gerek yok
            resultTextField.setText(currentText);
        }
        appendToOperation(".");
    }


    private String handleOperatorButton(String text) {
        switch (text) {
            case "×":
                return " * ";
            case "÷":
                return " / ";
            case "+":
                return " + ";
            case "-":
                return " - ";
            case "±":
                handleToggleSign();
                return "";
            case "=":
                calculateResult();
                return "";
            case "CE":
                handleCeButtonAction();
                return "";
            case "C":
                handleCButtonAction();
                return "";
            case "←":
                handleBackspaceButtonAction();
                return "";
            case "%":
                handelCalculatePercentage();
                return "";
            case "1/x":
                handleReciprocalButtonAction();
                return "";
            case "x²":
                handleSquareButtonAction();
                return "";
            case "√x":
                handleRootButtonAction();
                return "";
            case ".":
                return ".";
            default:
                return text;
        }
    }



// ...

    @FXML
    private void calculateResult() {
        try {
            Expression e = new ExpressionBuilder(operation.toString()).build();
            BigDecimal result = new BigDecimal(e.evaluate());
            if (operation.toString().contains("*") || operation.toString().contains("/")) {
                result = result.setScale(2, BigDecimal.ROUND_HALF_UP);
            }
            resultTextField.setText(result.stripTrailingZeros().toPlainString());
            lastResult = result.doubleValue(); // Sonucu hafızada tut
            startNewOperation = true; // Yeni işlem başlat
        } catch (Exception ex) {
            resultTextField.setText("Error");
        }
    }






    @FXML
    private void convertToBinary() {
        String currentText = resultTextField.getText();
        try {
            int decimal = Integer.parseInt(currentText);
            if (decimal < 0) {
                resultTextField.setText("Negatif sayılar ikili sistemde doğrudan gösterilemez.");
            } else if (decimal > Integer.MAX_VALUE) {
                resultTextField.setText("Çok büyük sayı.");
            } else {
                String binary = Integer.toBinaryString(decimal);
                resultTextField.setText(binary);
            }
        } catch (NumberFormatException e) {
            resultTextField.setText("Geçersiz Giriş");
        }
    }

    @FXML
    private void convertToHex() {
        String currentText = resultTextField.getText();
        try {
            int decimal = Integer.parseInt(currentText);
            String hex = Integer.toHexString(decimal);
            resultTextField.setText(hex.toUpperCase());
        } catch (NumberFormatException e) {
            resultTextField.setText("Invalid Input");
        }
    }

    @FXML
    private void convertToOct() {
        String currentText = resultTextField.getText();
        try {
            int decimal = Integer.parseInt(currentText);
            String octal = Integer.toOctalString(decimal);
            resultTextField.setText(octal);
        } catch (NumberFormatException e) {
            resultTextField.setText("Invalid Input");
        }
    }

}
